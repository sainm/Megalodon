﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            var text = "http://localhost:8000";
            WebRequest webRequest = WebRequest.Create(text);
            HttpWebResponse httpWebResponse = (HttpWebResponse)webRequest.GetResponse();
            Console.WriteLine();
        }
    }
}
