using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Threading;
using System.Windows.Forms;

namespace Megalodon
{
    [Guid("EC55F88B-1028-4F23-833C-17F0E0CA0D59")]
    [RunInstaller(true)]
    public class DllInstaller : Installer
    {
        private static bool is64BitProcess = IntPtr.Size == 8;

        private static bool is64BitOperatingSystem = is64BitProcess || InternalCheckIsWow64();

        private static string _ieVersion;

        private IContainer components;

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWow64Process([In] IntPtr hProcess, out bool wow64Process);

        public static bool InternalCheckIsWow64()
        {
            if ((Environment.OSVersion.Version.Major == 5 && Environment.OSVersion.Version.Minor >= 1) ||
                Environment.OSVersion.Version.Major >= 6)
            {
                using (Process process = Process.GetCurrentProcess())
                {
                    if (!IsWow64Process(process.Handle, out var wow64Process))
                    {
                        return false;
                    }

                    return wow64Process;
                }
            }

            return false;
        }

        private static void GetIeVersion()
        {
            string text = new WebBrowser().Version.ToString();
            _ieVersion = text.Substring(0, text.IndexOf('.'));
        }

        public DllInstaller()
        {
            InitializeComponent();
        }

        [SecurityPermission(SecurityAction.Demand)]
        public override void Commit(IDictionary savedState)
        {
            base.Commit(savedState);
        }

        [SecurityPermission(SecurityAction.Demand)]
        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
            Register();
        }

        [SecurityPermission(SecurityAction.Demand)]
        public override void Uninstall(IDictionary stateSaver)
        {
            base.Uninstall(stateSaver);
            Unregister();
        }

        private void ExecuteRegasm(bool unregister)
        {
            var thread = new Thread(GetIeVersion);
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            var text = RuntimeEnvironment.GetRuntimeDirectory() + "regasm.exe";
            var location = typeof(DllInstaller).Assembly.Location;
            var arguments = (unregister ? "/unregister " : "") + "\"" + location + "\"";
            Process.Start(text, arguments)?.WaitForExit();
            if (!is64BitOperatingSystem) return;
            var fileName = text.Replace("Framework", "Framework64");
            Process.Start(fileName, arguments)?.WaitForExit();
        }

        private void Register()
        {
            ExecuteRegasm(unregister: false);
        }

        private void Unregister()
        {
            ExecuteRegasm(unregister: true);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new Container();
        }
    }
}