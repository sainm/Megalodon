using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.Expando;
using Megalodon;
using Megalodon.Properties;
using Microsoft.Win32;
using mshtml;
using SHDocVw;

namespace RecorderBho
{
    [ComVisible(true)]
    [ProgId("KMS.qAutomate.RecorderBHO.Recorder")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComDefaultInterface(typeof(IHttpRequestExtension))]
    [Guid("FEA8CA38-7979-4F6A-83E4-2949EDEA96EF")]
    public class RecorderBHO : IObjectWithSite, IHttpRequestExtension
    {
        [Guid("6D5140C1-7436-11CE-8034-00AA006009FA")]
        [InterfaceType(1)]
        public interface IServiceProvider
        {
            int QueryService(ref Guid guidService, ref Guid riid, out IntPtr ppvObject);
        }

        private object site;

        private IWebBrowser2 browser;

        private static string serverUrl;

        private static string windowHandle;

        //private static string addonDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KMS", "qAutomate", "Recorder");

        public static string RegBHO = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Browser Helper Objects";

        private void OnDocumentComplete(object pDisp, ref object URL)
        {
            AddHttpRequestExtension();
            if (pDisp == site)
            {
                return;
            }
            try
            {
                IWebBrowser2 webBrowser = GetBrowser(pDisp);
                if (webBrowser != null)
                {
                    serverUrl = GetKatalonServerUrl();
                    if (serverUrl != null)
                    {
                        RunScriptOnDocument(webBrowser.Document as IHTMLDocument2);
                    }
                }
            }
            catch (Exception e)
            {
                LogError(e);
            }
        }

        private void OnDownloadComplete()
        {


            AddHttpRequestExtension();
            IHTMLDocument2 iHTMLDocument = browser.Document as IHTMLDocument2;
            if (iHTMLDocument == null || iHTMLDocument.parentWindow == null)
            {
                return;
            }
            try
            {
                IHTMLWindow2 parentWindow = iHTMLDocument.parentWindow;
                HTMLWindowEvents2_Event hTMLWindowEvents2_Event = parentWindow as HTMLWindowEvents2_Event;
                if (hTMLWindowEvents2_Event != null)
                {
                    new ComAwareEventInfo(typeof(HTMLWindowEvents2_Event), "onload").RemoveEventHandler(hTMLWindowEvents2_Event, new HTMLWindowEvents2_onloadEventHandler(OnLoad));
                    serverUrl = GetKatalonServerUrl();
                    if (serverUrl != null)
                    {
                        new ComAwareEventInfo(typeof(HTMLWindowEvents2_Event), "onload").AddEventHandler(hTMLWindowEvents2_Event, new HTMLWindowEvents2_onloadEventHandler(OnLoad));
                    }
                }
            }
            catch (Exception e)
            {
                LogError(e);
            }
        }

        public void OnLoad(IHTMLEventObj e)
        {

            AddHttpRequestExtension();
            try
            {
                RunScriptOnDocument(browser.Document as IHTMLDocument2);
            }
            catch (Exception e2)
            {
                LogError(e2);
            }
        }

        private void OnNavigateComplete(object pDisp, ref object URL)
        {
            AddHttpRequestExtension();
        }

        private void RunScriptOnDocument(IHTMLDocument2 document)
        {
            IHTMLWindow2 parentWindow = document.parentWindow;
            RunScriptOnWindow(parentWindow, this);
        }

        private void AddHttpRequestExtension()
        {
            try
            {
                HTMLDocument hTMLDocument = (HTMLDocument)(dynamic)browser.Document;
                dynamic parentWindow = hTMLDocument.parentWindow;
                IExpando expando = (IExpando)parentWindow;
                PropertyInfo propertyInfo = expando.GetProperty("httpRequestExtension", BindingFlags.Default);
                if (propertyInfo == null)
                {
                    propertyInfo = expando.AddProperty("httpRequestExtension");
                }
                propertyInfo.SetValue(expando, this, null);
            }
            catch (Exception e)
            {
                LogError(e);
            }
        }

        private void RunScriptOnWindow(IHTMLWindow2 window, IHttpRequestExtension extensionClass)
        {
            window.execScript(Resources.jquery_1_11_2_min);
            window.execScript(Resources.json3_min);
            window.execScript("windowId = '" + windowHandle + "';");
            window.execScript("qAutomate_server_url = '" + serverUrl + "';");
            window.execScript(Resources.constants);
            window.execScript(Resources.common);
            window.execScript(Resources.record_common);
            window.execScript(Resources.dom_recorder);
            window.execScript(Resources.main);
        }

        private IWebBrowser2 GetBrowser(object site)
        {
            if (site == null || !(site is IServiceProvider))
            {
                return null;
            }
            IServiceProvider serviceProvider = (IServiceProvider)site;
            Guid guidService = Marshal.GenerateGuidForType(typeof(IWebBrowserApp));
            Guid riid = Marshal.GenerateGuidForType(typeof(IWebBrowser2));
            serviceProvider.QueryService(ref guidService, ref riid, out var ppvObject);
            object objectForIUnknown = Marshal.GetObjectForIUnknown(ppvObject);
            if (objectForIUnknown is IWebBrowser2)
            {
                return (IWebBrowser2)objectForIUnknown;
            }
            return null;
        }

        private string GetKatalonServerUrl()
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            string text;
            do
            {
                // if (!Directory.Exists(addonDataFolder))
                // {
                //     return null;
                // }
                // text = Path.Combine(addonDataFolder, "serverUrl.txt");
                // if (!File.Exists(text))
                // {
                //     return null;
                // }
                // string text2 = File.ReadAllText(text);
                string text2 = "http://localhost:8000";
                try
                {
                    var webRequest = WebRequest.Create(text2);
                    var httpWebResponse = (HttpWebResponse)webRequest.GetResponse();
                    if (httpWebResponse.StatusCode == HttpStatusCode.OK)
                    {
                        return text2;
                    }
                }
                catch (Exception)
                {
                    // ignored
                }
            }
            while (stopwatch.ElapsedMilliseconds <= 5000);
            // if (text != null)
            // {
            //     File.Delete(text);
            // }
            return null;
        }

        private void LogError(Exception e)
        {
            if (e == null)
            {
                return;
            }
            try
            {
                // if (!Directory.Exists(addonDataFolder))
                // {
                //     Directory.CreateDirectory(addonDataFolder);
                // }
                // string path2 = Path.Combine(path2: DateTime.Now.Ticks / 10000 + ".log", path1: addonDataFolder);
                // File.WriteAllText(path2, e.ToString());
            }
            catch (Exception)
            {
            }
        }

        private IWebBrowser2 getBrowser(object site)
        {
            if (site != null && site is IServiceProvider)
            {
                IServiceProvider serviceProvider = (IServiceProvider)site;
                Guid guidService = Marshal.GenerateGuidForType(typeof(IWebBrowserApp));
                Guid riid = Marshal.GenerateGuidForType(typeof(IWebBrowser2));
                serviceProvider.QueryService(ref guidService, ref riid, out var ppvObject);
                object objectForIUnknown = Marshal.GetObjectForIUnknown(ppvObject);
                if (objectForIUnknown is IWebBrowser2)
                {
                    return (IWebBrowser2)objectForIUnknown;
                }
            }
            return null;
        }

        int IObjectWithSite.SetSite(object site)
        {
            if (site == null)
            {
                Dispose();
                browser = null;
                windowHandle = null;
                return 0;
            }
            try
            {
                this.site = site;
                browser = GetBrowser(site);
                windowHandle = Guid.NewGuid().ToString();
                Setup();
            }
            catch (Exception e)
            {
                LogError(e);
            }
            return 0;
        }

        private void Dispose()
        {
            new ComAwareEventInfo(typeof(DWebBrowserEvents2_Event), "DocumentComplete").RemoveEventHandler((DWebBrowserEvents2_Event)browser, new DWebBrowserEvents2_DocumentCompleteEventHandler(OnDocumentComplete));
            new ComAwareEventInfo(typeof(DWebBrowserEvents2_Event), "DownloadComplete").RemoveEventHandler((DWebBrowserEvents2_Event)browser, new DWebBrowserEvents2_DownloadCompleteEventHandler(OnDownloadComplete));
            new ComAwareEventInfo(typeof(DWebBrowserEvents2_Event), "NavigateComplete2").RemoveEventHandler((DWebBrowserEvents2_Event)browser, new DWebBrowserEvents2_NavigateComplete2EventHandler(OnNavigateComplete));
        }

        private void Setup()
        {
            new ComAwareEventInfo(typeof(DWebBrowserEvents2_Event), "DocumentComplete").AddEventHandler((DWebBrowserEvents2_Event)browser, new DWebBrowserEvents2_DocumentCompleteEventHandler(OnDocumentComplete));
            new ComAwareEventInfo(typeof(DWebBrowserEvents2_Event), "DownloadComplete").AddEventHandler((DWebBrowserEvents2_Event)browser, new DWebBrowserEvents2_DownloadCompleteEventHandler(OnDownloadComplete));
            new ComAwareEventInfo(typeof(DWebBrowserEvents2_Event), "NavigateComplete2").AddEventHandler((DWebBrowserEvents2_Event)browser, new DWebBrowserEvents2_NavigateComplete2EventHandler(OnNavigateComplete));
        }

        int IObjectWithSite.GetSite(ref Guid guid, out IntPtr ppvSite)
        {
            try
            {
                IntPtr iUnknownForObject = Marshal.GetIUnknownForObject(browser);
                int result = Marshal.QueryInterface(iUnknownForObject, ref guid, out ppvSite);
                Marshal.Release(iUnknownForObject);
                return result;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw ex;
            }
        }

        [ComRegisterFunction]
        public static void RegisterBHO(Type type)
        {
            string text = type.GUID.ToString("B");
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(RegBHO, writable: true);
            if (registryKey == null)
            {
                registryKey = Registry.LocalMachine.CreateSubKey(RegBHO);
            }

            RegistryKey registryKey2 = registryKey.OpenSubKey(text);
            if (registryKey2 == null)
            {
                registryKey2 = registryKey.CreateSubKey(text);
            }

            registryKey2.SetValue("Alright", 1);
            registryKey.Close();
            registryKey2.Close();
        }
        [ComUnregisterFunction]
        public static void UnregisterBho(Type type)
        {
            string subkey = type.GUID.ToString("B");
            Registry.LocalMachine.OpenSubKey(RegBHO, writable: true)?.DeleteSubKey(subkey, throwOnMissingSubKey: false);
        }

        public string postRequest(string data, string url)
        {
            using WebClient webClient = new WebClient();
            try
            {
                webClient.UploadString(url, data);
                return "200";
            }
            catch (WebException ex)
            {
                if (ex.Response is HttpWebResponse)
                {
                    HttpWebResponse httpWebResponse = (HttpWebResponse)ex.Response;
                    return "HTTP Status Code: " + (int)httpWebResponse.StatusCode;
                }
                if (ex.Message.Contains("Unable to connect to the remote server"))
                {
                    return "Cannot connect to Katalon Server. Make sure you have started Recorder on Katalon application.";
                }
                return "Web Exception Error: " + ex.Message;
            }
            catch (Exception ex2)
            {
                LogError(ex2);
                return "Internal Error: " + ex2.ToString();
            }
        }
    }
}
