using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Megalodon.Properties
{
    [DebuggerNonUserCode]
    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
    [CompilerGenerated]
    internal class Resources
    {
        private static ResourceManager resourceMan;

        private static CultureInfo resourceCulture;

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static ResourceManager ResourceManager
        {
            get
            {
                if (ReferenceEquals(resourceMan, null))
                {
                    ResourceManager resourceManager = resourceMan = new ResourceManager("Megalodon.Properties.Resources", typeof(Resources).Assembly);
                }
                return resourceMan;
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static CultureInfo Culture
        {
            get
            {
                return resourceCulture;
            }
            set
            {
                resourceCulture = value;
            }
        }

        internal static string common => ResourceManager.GetString("common", resourceCulture);

        internal static string constants => ResourceManager.GetString("constants", resourceCulture);

        internal static string dom_recorder => ResourceManager.GetString("dom_recorder", resourceCulture);

        internal static string jquery_1_11_2_min => ResourceManager.GetString("jquery_1_11_2_min", resourceCulture);

        internal static string json3_min => ResourceManager.GetString("json3_min", resourceCulture);

        internal static string main => ResourceManager.GetString("main", resourceCulture);

        internal static string record_common => ResourceManager.GetString("record_common", resourceCulture);

        internal Resources()
        {
        }
    }
}
